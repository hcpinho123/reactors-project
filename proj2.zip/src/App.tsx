import { Route, Routes } from "react-router";
import "./App.css";
import Dashboard from "./pages/Dashboard";
import { ReactorPage } from "./pages/ReactorPage";

function App() {
  return (
    <Routes>
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/reactor/:id" element={<ReactorPage />} />
    </Routes>
  );
}

export default App;
