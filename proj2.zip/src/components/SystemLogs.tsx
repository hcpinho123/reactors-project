import { useEffect, useState } from "react";
import { LogsType } from "../types/LogsType";
import { Typography } from "@mui/material";

export function SystemLogs() {
  const [logs, setLogs] = useState<LogsType[] | null>(null);

  useEffect(() => {
    const intervalId: number = setInterval(async () => {
      async function fetchLogs() {
        const rawResponse = await fetch(
          `https://nuclear.dacoder.io/reactors/logs?apiKey=1bb4dff552124f3c`
        );
        const parsedResponse = await rawResponse.json();
        setLogs(parsedResponse);
      }
      await fetchLogs();
    }, 1000);

    return () => clearInterval(intervalId);
  }, [logs]);

  return (
    <>
      {logs?.map((log, index) => {
        const logId = Object.keys(log)[0]; // Extract the log ID
        const events = log[logId]; // Access the array of events for the log ID

        return (
          <div key={index}>
            {events.map((event: string, eventIndex: number) => (
              <Typography key={eventIndex} variant="subtitle2">
                {event}
              </Typography>
            ))}
          </div>
        );
      })}
    </>
  );
}
